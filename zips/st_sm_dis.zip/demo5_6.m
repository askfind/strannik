// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use OpenGL)
// Demo 5.6:Color text

module Demo5_6;
import Win32;

const hINSTANCE=0x400000;
const className="StrannikGL";
const GL_START_LIST=1000;

var
 WindowClass:WNDCLASS;
 hwnd:HWND;
 Message:MSG;
 dc:HDC;

 pos, koif:real32;
 stop:boolean;

 lightpos:array[0..3]of GLfloat;    //lamp position
 lightdirect:array[0..2]of GLfloat;  //lamp line
 matdiffus:array[0..3]of GLfloat;
 matspecul:array[0..3]of GLfloat;

procedure InitLight();
begin
   lightpos[0]:=real32(0.0); lightpos[1]:=real32(3.0); lightpos[2]:=real32(4.0); lightpos[3]:=real32(1.0);
   lightdirect[0]:=real32(0.0); lightdirect[1]:=real32(-0.6); lightdirect[2]:=real32(-0.7);
   glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, real32(4));
   glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, real32(50));
   glEnable(GL_LIGHT0);
   glEnable(GL_LIGHTING);
end InitLight;

procedure InitMat();
begin
  matdiffus[0]:=real32(0.8);  matdiffus[1]:=real32(0.0);  matdiffus[2]:=real32(0.8);  matdiffus[3]:=real32(1.0);
  matspecul[0]:=real32(0.4);   matspecul[1]:=real32(0.6);   matspecul[2]:=real32(0.4);  matspecul[3]:=real32(1.0);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, matdiffus[0]);
  glMaterialfv(GL_FRONT, GL_SPECULAR, matspecul[0]);
end InitMat;

procedure InitText(hdc:HDC);
var hFontNew,hOldFont:HFONT;
begin
  hFontNew:=CreateFont(-28, 0, 0, 0, FW_BOLD, 1, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS,
                                      CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 34, "Arial Cyr");
  hOldFont:=SelectObject(hdc, hFontNew);

   wglUseFontOutlinesA(hdc, 0, 255,GL_START_LIST, real32(0.0), real32(0.2), WGL_FONT_POLYGONS, nil);

   SelectObject(hdc, hOldFont);
   DeleteObject(hFontNew);
end InitText;

procedure OutText(txt:pstr);
var ln:integer;
begin
   glListBase(GL_START_LIST);
   ln:=lstrlen(txt);
   glCallLists(ln, GL_UNSIGNED_BYTE, txt);
end OutText;

procedure InitGL(hWnd:HWND):boolean;
var
  hrc:HGLRC;
  pfd:PIXELFORMATDESCRIPTOR;
  nPixelFormat:integer;
begin
 hrc:=0;
 dc:=GetDC(hWnd);

 RtlZeroMemory(&pfd,  sizeof (PIXELFORMATDESCRIPTOR));
 with pfd do
   nSize:=sizeof (PIXELFORMATDESCRIPTOR);
   nVersion:=1;
   dwFlags:=PFD_DRAW_TO_WINDOW or PFD_SUPPORT_OPENGL or PFD_DOUBLEBUFFER;
   iPixelType:=PFD_TYPE_RGBA;
   cColorBits:=16;
   cDepthBits:=32;
   iLayerType:=PFD_MAIN_PLANE;
  end;

  nPixelFormat:=ChoosePixelFormat (dc, &pfd);
  SetPixelFormat (dc, nPixelFormat, &pfd);

  hrc:=wglCreateContext (dc);
  if hrc = 0 then return false end;
  wglMakeCurrent(dc,hrc);

  InitText(dc);

  glClearColor (real32(0),real32(0),real32(0),real32(0.0));

  InitLight();
  InitMat();
 
  glEnable(GL_NORMALIZE);
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
  return true;
end InitGL;

procedure ResizeGL(hWnd:HWND);
var
  rc:RECT;
  sz,r,b:real;
begin
  GetClientRect(hWnd,rc);
  r:=real(rc.right);
  b:=real(rc.bottom);
  sz:=r / b;
  glViewport(0,0, rc.right, rc.bottom);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0, sz, 1.0, 40.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
end ResizeGL;

procedure CloseGL(hWnd:HWND);
var rc:HGLRC;
begin  
  glDeleteLists(GL_START_LIST, 256);
   rc:=wglGetCurrentContext();
   if not(rc = 0) then
      wglMakeCurrent(dc, 0);
      ReleaseDC(hWnd, dc);
      wglDeleteContext(rc);
   end
end CloseGL;
                     
procedure Anim();
begin
  if pos > real32( 4.0) then  koif:=real32( -0.04) end;
  if pos < real32( -4.0) then koif:=real32( 0.04) end;
  pos:=pos + koif;
end Anim;

procedure DrawGL(hWnd:HWND);
var i,j,n:integer;
begin
  lightpos[0]:=pos;
  
  glLoadIdentity();
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glTranslatef(real32(0.0), real32(0.0), real32(-7.0));
  glRotatef(real32(27.0), real32(1.0), real32(0.0), real32(0.0));
  glRotatef(real32(25.0), real32(0.0), real32(1.0), real32(0.0));

  glLightfv(GL_LIGHT0, GL_POSITION, lightpos[0]);
  glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightdirect[0]);
 
  glTranslatef(real32(-3.0), real32(0.0), real32(0.0));
  OutText("StrannikGL");
   
  glFinish();
  SwapBuffers(dc);
end DrawGL;

procedure wndProc(hWnd:HWND; msg,wParam,lParam:integer):boolean;
begin
  case msg of
    WM_CREATE:if (InitGL(hWnd) = false) then MessageBox(0,"OpenGL load error","Error",0) end;
                                   SetTimer(hWnd, 1, 20, nil);
                                   pos:=real32( -4.0);
                                   koif:=real32( 0.04);|
    WM_SIZE:ResizeGL(hWnd);|
    WM_TIMER:Anim();|
    WM_DESTROY:CloseGL(hWnd);
                                     KillTimer(hWnd,1);
                                     PostQuitMessage(0);
                                     return(DefWindowProc(hWnd,msg,wParam,lParam));|
    else return(DefWindowProc(hWnd,msg,wParam,lParam));
  end
end wndProc;

begin
  with WindowClass do
    style             := 0;
    lpfnWndProc:=&wndProc;
    cbClsExtra:=0;
    cbWndExtra:=0;
    hInstance:=hINSTANCE;    
    hIcon:=0;
    hCursor:=LoadCursor(0,pstr(IDC_ARROW));
    hbrBackground:=COLOR_WINDOW;
    lpszMenuName:=nil;
    lpszClassName:=className;
   end;
   RegisterClass(WindowClass);

   hwnd:=CreateWindowEx(0,className,"OpenGL",WS_OVERLAPPEDWINDOW or WS_CLIPCHILDREN or WS_CLIPSIBLINGS,
                                        100,100,400,300, 0,0,hINSTANCE,nil);

  if (hwnd = 0) then MessageBox(0,"Window create error","Error ",0) end;

  ShowWindow(hwnd,SW_MAXIMIZE);
  UpdateWindow(hwnd);

 //messages loop
 stop:=true; 
  while stop do
     if PeekMessage (Message, 0, 0, 0, PM_NOREMOVE) then
        if not GetMessage(Message, 0, 0, 0) then stop:=false;
        else
          TranslateMessage (Message);
          DispatchMessage (Message);
        end
     else DrawGL(hwnd);
     end
  end
end Demo5_6.

