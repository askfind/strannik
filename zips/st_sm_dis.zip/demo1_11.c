// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use Win32)
// Demo 2.11:String operators

include Win32,Win32Ext

char* s; 
char str[11];

void main()
{
//add
  s="3";
  MessageBox(0,"1"+"2"+s,"123",0);
//set string
  str="0123456789";
  MessageBox(0,str,"0123456789",0);
//string + pstr
  MessageBox(0,str+":","0123456789:",0);
//pstr + char
  MessageBox(0,s+(char*)':',"3:",0);
//equal and others
  if ("3"==s) MessageBox(0,"ok","ok",0); else MessageBox(0,"error","ok",0);
  if ("2"!=s) MessageBox(0,"ok","ok",0); else MessageBox(0,"error","ok",0);
  if ("2"<s) MessageBox(0,"ok","ok",0); else MessageBox(0,"error","ok",0);
  if ("4">s) MessageBox(0,"ok","ok",0); else MessageBox(0,"error","ok",0);
  if ("2"<=s) MessageBox(0,"ok","ok",0); else MessageBox(0,"error","ok",0);
  if ("4">=s) MessageBox(0,"ok","ok",0); else MessageBox(0,"error","ok",0);
//printi
  MessageBox(0,printi(128)+":","128:",0);
//printx
  MessageBox(0,printx(0xFF)+":","ff:",0);
//printr
  MessageBox(0,printr(1.22,2)+":","1.22:",0);
//printe
  MessageBox(0,printe(0.922)+":","0.922:",0);
//delete
  MessageBox(0,delete("0123456789",2,2),"01456789",0);
}

