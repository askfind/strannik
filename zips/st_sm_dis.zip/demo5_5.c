// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use OpenGL)
// Demo 5.5:Rolling piramide

#include "Win32.h"

#define hINSTANCE 0x400000
#define className "StrannikGL"

WNDCLASS WindowClass;
HWND hwnd;
MSG Message;
HDC dc;

bool stop;
float32 angle;

bool InitGL(HWND hWnd)
 {
  HGLRC hrc;
  PIXELFORMATDESCRIPTOR pfd; //pixel format
  int  nPixelFormat;

 hrc = 0;
 dc = GetDC(hWnd);

  with (pfd)
  {
   nSize = sizeof (PIXELFORMATDESCRIPTOR);
   nVersion = 1;
   dwFlags = PFD_DRAW_TO_WINDOW or PFD_SUPPORT_OPENGL or PFD_DOUBLEBUFFER;
   iPixelType = PFD_TYPE_RGBA;
   cColorBits = 16;
   cRedBits = 0;
   cRedShift = 0;
   cGreenBits = 0;
   cGreenShift = 0;
   cBlueBits = 0;
   cBlueShift = 0;
   cAlphaBits = 0;
   cAlphaShift = 0;
   cAccumBits = 0;
   cAccumRedBits = 0;
   cAccumGreenBits = 0;
   cAccumBlueBits = 0;
   cAccumAlphaBits = 0;
   cDepthBits = 32;
   cStencilBits = 0;
   cAuxBuffers = 0;
   iLayerType = PFD_MAIN_PLANE;
   bReserved = 0;
   dwLayerMask = 0;
   dwVisibleMask = 0;
   dwDamageMask = 0;
  }

  nPixelFormat = ChoosePixelFormat (dc, &pfd);
  SetPixelFormat (dc, nPixelFormat, &pfd);

  hrc = wglCreateContext (dc);
  if (hrc = 0) return false;
  wglMakeCurrent(dc,hrc);

  glClearColor ((float32)0,(float32)0,(float32)0,(float32)1.0);
  glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, (float32)4);
  glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, (float32)50);
  glEnable(GL_LIGHT0);
  glEnable(GL_LIGHTING);
  glEnable(GL_COLOR_MATERIAL);
  glEnable(GL_NORMALIZE);
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
  return true;
 }

void ResizeGL(HWND hWnd)
 {
  RECT rc;
  float sz,r,b;

  GetClientRect(hWnd, &rc);
  r = (float)rc.right;
  b = (float)rc.bottom;
  sz = r / b;
  glViewport(0,0, rc.right, rc.bottom);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0, sz, 1.0, 40.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
 }

void CloseGL(HWND hWnd)
 {
   HGLRC rc;
  
   rc = wglGetCurrentContext();
   if (!(rc = 0))
    {
      wglMakeCurrent(dc, 0);
      ReleaseDC(hWnd, dc);
      wglDeleteContext(rc);
    }
 }

void NormalVector(float *x, float *y, float *z, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3)
 {
  *x = (y2-y1)*(z3-z1)-(y3-y1)*(z2-z1);
  *y = (x3-x1)*(z2-z1)-(x2-x1)*(z3-z1);
  *z = (x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
 }

void TriangleDraw(float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3)
 {
  float nx, ny, nz;

  NormalVector(&nx, &ny, &nz, x1, y1, z1, x2, y2, z2, x3, y3, z3);
  glNormal3f((float32)nx, (float32)ny, (float32)nz);
  glBegin(GL_TRIANGLES);
    glVertex3f ((float32)x1, (float32)y1, (float32)z1);
    glVertex3f ((float32)x2, (float32)y2, (float32)z2);
    glVertex3f ((float32)x3, (float32)y3, (float32)z3);
  glEnd();  
 }


void DrawGL(HWND hWnd)
 {

  int i,j,n;
  float nx,ny,nz;
  GLfloat lightpos[4] ;
  GLfloat lightdirect[3];

  lightpos[0] = (float32)3.0; lightpos[1] = (float32)3.0; lightpos[2] = (float32)4.0; lightpos[3] = (float32)1.0;
  lightdirect[0] = (float32)-0.5; lightdirect[1] = (float32)-0.6; lightdirect[2] = (float32)-0.7;

  glLoadIdentity();
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
  glTranslatef((float32)0.0, (float32)0.0, (float32)-10.0);
  glRotatef((float32)27.0, (float32)1.0, (float32)0.0, (float32)0.0);
  glRotatef(angle, (float32)0.0, (float32)1.0, (float32)0.0);   

  glLightfv(GL_LIGHT0, GL_POSITION, lightpos[0]);
  glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightdirect[0]);
 
  glColor3f((float32)1.0, (float32)1.0, (float32)0.0);

  TriangleDraw(0.0, 3.0, 0.0, 2.0, 0.0, 2.0, 2.0, 0.0, -2.0); 
  TriangleDraw(0.0, 3.0, 0.0, -2.0, 0.0, 2.0, 2.0, 0.0, 2.0);
  TriangleDraw(0.0, 3.0, 0.0, -2.0, 0.0, -2.0, -2.0, 0.0, 2.0); 
  TriangleDraw(0.0, 3.0, 0.0, 2.0, 0.0, -2.0, -2.0, 0.0, -2.0);

 glNormal3f((float32)0.0, (float32)1.0, (float32)0.0);
  for (i = -5; i<5; i++)
    for (j = -5; j<=5; j++)
     {
       if (n =1)
         {
           glColor3f((float32)1.0, (float32)0.0, (float32)0.0); 
           n = 0;
          }
       else
         {
           glColor3f((float32)0.8, (float32)0.8, (float32)0.8);
           n =1;
         }
        glBegin(GL_QUADS);
          glVertex3f ((float32)i,(float32) 0.0, (float32)j);
          glVertex3f ((float32)i+1, (float32)0.0, (float32)j);
          glVertex3f ((float32)i+1, (float32)0.0, (float32)j+1);
          glVertex3f ((float32)i, (float32)0.0, (float32)j+1);
        glEnd(); 
     }

  glFinish();
  SwapBuffers(dc);
 }

bool wndProc(HWND hWnd,uint msg,uint wParam,uint lParam)
{
  switch(msg) 
  {                                                                                
    case WM_CREATE: if (InitGL(hWnd) = false) MessageBox(0,"OpenGL not init","Error",0);
                                   SetTimer(hWnd, 1, 20, nil);
                                   break;
    case WM_SIZE: ResizeGL(hWnd);
                             break;
    case WM_TIMER: if (angle < (float32)360.0) angle = angle + (float32)0.2;
                                else angle = (float32)0.0; 
                              break;
    case WM_DESTROY: CloseGL(hWnd);
                                     KillTimer(hWnd,1);
                                     PostQuitMessage(0);
                                     return(DefWindowProc(hWnd,msg,wParam,lParam));
                                     break;
    default:return(DefWindowProc(hWnd,msg,wParam,lParam));
               break;
  }
}

void main()
 {
  with(WindowClass)
   {
    style              =  0;
    lpfnWndProc = &wndProc;
    cbClsExtra=0;
    cbWndExtra=0;
    hInstance=hINSTANCE;    
    hIcon=0;
    hCursor=LoadCursor(0,pchar(IDC_ARROW));
    hbrBackground=COLOR_WINDOW;
    lpszMenuName=nil;
    lpszClassName=className;
   }
   RegisterClass(WindowClass);

   hwnd = CreateWindowEx(0,className,"OpenGL",WS_OVERLAPPEDWINDOW or WS_CLIPCHILDREN or WS_CLIPSIBLINGS,
                                        100,100,400,300, 0,0,hINSTANCE,nil);

  ShowWindow(hwnd,SW_SHOW);
  UpdateWindow(hwnd);

 //messages loop
 stop = true; 
  while(stop)
   {
     if (PeekMessage (Message, 0, 0, 0, PM_NOREMOVE))
      {
        if (!GetMessage(Message, 0, 0, 0))
           stop = false;
        else
          {
          TranslateMessage (Message);
          DispatchMessage (Message);
         }
      } 
     else
      {
        DrawGL(hwnd);
      }
   }
  }

