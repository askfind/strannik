// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use OpenGL)
// Demo 5.5:Rolling piramide

module Demo5_5;
import Win32;

const hINSTANCE=0x400000;
const className="StrannikGL";

var
  WindowClass:WNDCLASS;
  hwnd:HWND;
  Message:MSG;
  dc:HDC;

  stop:boolean;
  angle:real32;

procedure InitGL(hWnd:HWND):boolean;
var
  hrc:HGLRC;
  pfd:PIXELFORMATDESCRIPTOR; //pixels format
  nPixelFormat:integer;
begin
  hrc:=0;
  dc:=GetDC(hWnd);
  with pfd do
   nSize:=sizeof(PIXELFORMATDESCRIPTOR);
   nVersion:=1;
   dwFlags:=PFD_DRAW_TO_WINDOW or PFD_SUPPORT_OPENGL or PFD_DOUBLEBUFFER;
   iPixelType:=PFD_TYPE_RGBA;
   cColorBits:=16;
   cRedBits:=0;
   cRedShift:=0;
   cGreenBits:=0;
   cGreenShift:=0;
   cBlueBits:=0;
   cBlueShift:=0;
   cAlphaBits:=0;
   cAlphaShift:=0;
   cAccumBits:=0;
   cAccumRedBits:=0;
   cAccumGreenBits:=0;
   cAccumBlueBits:=0;
   cAccumAlphaBits:=0;
   cDepthBits:=32;
   cStencilBits:=0;
   cAuxBuffers:=0;
   iLayerType:=PFD_MAIN_PLANE;
   bReserved:=0;
   dwLayerMask:=0;
   dwVisibleMask:=0;
   dwDamageMask:=0;
  end;
  nPixelFormat:=ChoosePixelFormat(dc,pfd);
  SetPixelFormat(dc,nPixelFormat,pfd);

  hrc:=wglCreateContext(dc);
  if(hrc=0) then return false end;
  wglMakeCurrent(dc,hrc);

  glClearColor(real32(0),real32(0),real32(0),real32(1.0));
  glLightf(GL_LIGHT0,GL_SPOT_EXPONENT,real32(4));
  glLightf(GL_LIGHT0,GL_SPOT_CUTOFF,real32(50));
  glEnable(GL_LIGHT0);
  glEnable(GL_LIGHTING);
  glEnable(GL_COLOR_MATERIAL);
  glEnable(GL_NORMALIZE);
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
  return true;
end InitGL;
*/
procedure ResizeGL(hWnd:HWND);
var
  rc:RECT;
  sz,r,b:real;
begin
  GetClientRect(hWnd,rc);
  r:=real(rc.right);
  b:=real(rc.bottom);
  sz:=r/b;
  glViewport(0,0,rc.right,rc.bottom);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0,sz,1.0,40.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
end ResizeGL;

procedure CloseGL(hWnd:HWND);
var
  rc:HGLRC;
begin  
   rc:=wglGetCurrentContext();
   if (rc<>0) then
      wglMakeCurrent(dc,0);
      ReleaseDC(hWnd,dc);
      wglDeleteContext(rc);
   end
end CloseGL;

procedure NormalVector(var x,y,z:real; x1,y1,z1,x2,y2,z2,x3,y3,z3:real);
begin
  x:=(y2-y1)*(z3-z1)-(y3-y1)*(z2-z1);
  y:=(x3-x1)*(z2-z1)-(x2-x1)*(z3-z1);
  z:=(x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
end NormalVector;

procedure TriangleDraw(x1,y1,z1,x2,y2,z2,x3,y3,z3:real);
var nx,ny,nz:real;
begin
  NormalVector(nx,ny,nz,x1,y1,z1,x2,y2,z2,x3,y3,z3);
  glNormal3f(real32(nx),real32(ny),real32(nz));
  glBegin(GL_TRIANGLES);
  glVertex3f(real32(x1),real32(y1),real32(z1));
  glVertex3f(real32(x2),real32(y2),real32(z2));
  glVertex3f(real32(x3),real32(y3),real32(z3));
  glEnd();  
end TriangleDraw;

procedure DrawGL(hWnd:HWND);
var
  i,j,n:integer;
  nx,ny,nz:real;
  lightpos:array[0..3]of GLfloat;
  lightdirect:array[0..2]of GLfloat;
begin
  lightpos[0]:=real32(3.0); lightpos[1]:=real32(3.0); lightpos[2]:=real32(4.0); lightpos[3]:=real32(1.0);
  lightdirect[0]:=real32(-0.5); lightdirect[1]:=real32(-0.6); lightdirect[2]:=real32(-0.7);

  glLoadIdentity();
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
  glTranslatef(real32(0.0), real32(0.0), real32(-10.0));
  glRotatef(real32(27.0), real32(1.0), real32(0.0), real32(0.0));
  glRotatef(angle, real32(0.0), real32(1.0), real32(0.0));   

  glLightfv(GL_LIGHT0, GL_POSITION, lightpos[0]);
  glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightdirect[0]);
 
  glColor3f(real32(1.0), real32(1.0), real32(0.0));

  TriangleDraw(0.0, 3.0, 0.0, 2.0, 0.0, 2.0, 2.0, 0.0, -2.0); 
  TriangleDraw(0.0, 3.0, 0.0, -2.0, 0.0, 2.0, 2.0, 0.0, 2.0);
  TriangleDraw(0.0, 3.0, 0.0, -2.0, 0.0, -2.0, -2.0, 0.0, 2.0); 
  TriangleDraw(0.0, 3.0, 0.0, 2.0, 0.0, -2.0, -2.0, 0.0, -2.0);
*/
  glNormal3f(real32(0.0), real32(1.0), real32(0.0));
  for i:=-5 to 4 do
  for j:=-5 to 4 do
     if (n =1) then
         glColor3f(real32(1.0), real32(0.0), real32(0.0)); 
         n:=0;
     else
         glColor3f(real32(0.8), real32(0.8), real32(0.8));
         n:=1;
     end;
     glBegin(GL_QUADS);
     glVertex3f (real32(i),real32(0.0), real32(j));
     glVertex3f (real32(i+1), real32(0.0), real32(j));
     glVertex3f (real32(i+1), real32(0.0), real32(j+1));
     glVertex3f (real32(i), real32(0.0), real32(j+1));
     glEnd(); 
  end end;

  glFinish();
  SwapBuffers(dc);
end DrawGL;

procedure wndProc(hWnd:HWND; msg,wparam,lparam:cardinal):boolean;
begin
  case msg of
    WM_CREATE:
      if (InitGL(hWnd)=false) then MessageBox(0,"OpenGL not init","Error",0) end;
      SetTimer(hWnd, 1, 20, nil);|
    WM_SIZE:ResizeGL(hWnd);|
    WM_TIMER:
      if angle<real32(360.0)
        then angle:=angle + real32(0.2);
        else angle:=real32(0.0); 
      end;|
    WM_DESTROY:
      CloseGL(hWnd);
      KillTimer(hWnd,1);
      PostQuitMessage(0);
      return DefWindowProc(hWnd,msg,wparam,lparam);|
    else return DefWindowProc(hWnd,msg,wparam,lparam);
  end
end wndProc;

begin
  RtlZeroMemory(addr(WindowClass),sizeof(WNDCLASS));
  with WindowClass do
    style:=CS_HREDRAW | CS_VREDRAW;
    lpfnWndProc:=addr(wndProc);
    hInstance:=hINSTANCE;    
    hbrBackground:=COLOR_WINDOW;
    lpszClassName:=className;
  end;
  RegisterClass(WindowClass);                     
  hwnd:=CreateWindowEx(0,className,"OpenGL",WS_OVERLAPPEDWINDOW or WS_CLIPCHILDREN or WS_CLIPSIBLINGS,
    100,100,400,300, 0,0,hINSTANCE,nil);
  ShowWindow(hwnd,SW_SHOW);
  UpdateWindow(hwnd);

 //messages loop
  stop:=true; 
  while stop do
    if PeekMessage(Message, 0, 0, 0, PM_NOREMOVE) then
      if not GetMessage(Message, 0, 0, 0) then stop:=false;
      else
        TranslateMessage (Message);
        DispatchMessage (Message);
      end
    else
      DrawGL(hwnd);
    end
  end
end Demo5_5.

