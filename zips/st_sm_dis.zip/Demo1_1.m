// STRANNIK Modula-C-Pascal for Win32
// Demo program
// Demo 1:MessageBox

module Demo1_1;
import Win32;

begin
  MessageBox(0,"Text","Caption",0);
end Demo1_1.

