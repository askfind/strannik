// STRANNIK Modula-C-Pascal for Win32
// Demo program
// Demo 1:MessageBox

include Win32

void main() {
  MessageBox(0,"Text","Caption",0);
}

