// STRANNIK Modula-C-Pascal for Win32
// Demo program
// Demo 11:String operations

module Demo1_11;
import Win32,Win32Ext;

var s:pstr; str:string[10];

begin
//add
  s:="3";
  MessageBox(0,"1"+"2"+s,"123",0);
//set
  str:="0123456789";
  MessageBox(0,str,"0123456789",0);
//string + pstr
  MessageBox(0,str+":","0123456789:",0);
//pstr + char
  MessageBox(0,s+pstr(':'),"3:",0);
//equal an others
  if "3"=s then MessageBox(0,"ok","ok",0) else MessageBox(0,"error","ok",0) end;
  if "2"<>s then MessageBox(0,"ok","ok",0) else MessageBox(0,"error","ok",0) end;
  if "2"<s then MessageBox(0,"ok","ok",0) else MessageBox(0,"error","ok",0) end;
  if "4">s then MessageBox(0,"ok","ok",0) else MessageBox(0,"error","ok",0) end;
  if "2"<=s then MessageBox(0,"ok","ok",0) else MessageBox(0,"error","ok",0) end;
  if "4">=s then MessageBox(0,"ok","ok",0) else MessageBox(0,"error","ok",0) end;
//printi
  MessageBox(0,printi(128)+":","128:",0);
//printx
  MessageBox(0,printx(0xFF)+":","ff:",0);
//printr
  MessageBox(0,printr(1.22,2)+":","1.22:",0);
//printe
  MessageBox(0,printe(0.922)+":","0.922:",0);
//delete
  MessageBox(0,delete("0123456789",2,2),"01456789",0);
end Demo1_11.

