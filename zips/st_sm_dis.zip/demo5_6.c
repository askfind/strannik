// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use OpenGL)
// Demo 5.6:Color text

#include Win32

#define hINSTANCE 0x400000
#define className "StrannikGL"
#define GL_START_LIST 1000

 WNDCLASS WindowClass;
 HWND hwnd;
 MSG Message;
 HDC dc;

 float32 pos, koif;
 bool stop;

 GLfloat lightpos[4] ;    //lamp position
 GLfloat lightdirect[3];  //lamp line
 GLfloat matdiffus[4];    
 GLfloat matspecul[4];

void InitLight()
 {
   lightpos[0] = (float32)0.0; lightpos[1] = (float32)3.0; lightpos[2] = (float32)4.0; lightpos[3] = (float32)1.0;
   lightdirect[0] = (float32)0.0; lightdirect[1] = (float32)-0.6; lightdirect[2] = (float32)-0.7;
   glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, (float32)4);
   glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, (float32)50);
   glEnable(GL_LIGHT0);
   glEnable(GL_LIGHTING);
 }

void InitMat()
 {
  matdiffus[0] = (float32)0.8;  matdiffus[1] = (float32)0.0;  matdiffus[2] = (float32)0.8;  matdiffus[3] = (float32)1.0;
  matspecul[0] = (float32)0.4;   matspecul[1] = (float32)0.6;   matspecul[2] = (float32)0.4;  matspecul[3] = (float32)1.0;
  glMaterialfv(GL_FRONT, GL_DIFFUSE, matdiffus[0]);
  glMaterialfv(GL_FRONT, GL_SPECULAR, matspecul[0]);
 }

void InitText(HDC hdc)
 {
  HFONT hFontNew, hOldFont;

  hFontNew = CreateFont(-28, 0, 0, 0, FW_BOLD, 1, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS,
                                      CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 34, "Arial Cyr");
  hOldFont = SelectObject(hdc, hFontNew);

   wglUseFontOutlinesA(hdc, 0, 255,GL_START_LIST, (float32)0.0, (float32)0.2, WGL_FONT_POLYGONS, nil);

   SelectObject(hdc, hOldFont);
   DeleteObject(hFontNew);
 }

void OutText(pchar txt)
 {
   uint ln;
   glListBase(GL_START_LIST);
   ln = lstrlen(txt);
   glCallLists(ln, GL_UNSIGNED_BYTE, txt);
 }

bool InitGL(HWND hWnd)
 {
  HGLRC hrc;
  PIXELFORMATDESCRIPTOR pfd; //pixel format
  int nPixelFormat;

 hrc = 0;
 dc = GetDC(hWnd);

 RtlZeroMemory(&pfd,  sizeof (PIXELFORMATDESCRIPTOR));
 with (pfd)
  {
   nSize = sizeof (PIXELFORMATDESCRIPTOR);
   nVersion = 1;
   dwFlags = PFD_DRAW_TO_WINDOW or PFD_SUPPORT_OPENGL or PFD_DOUBLEBUFFER;
   iPixelType = PFD_TYPE_RGBA;
   cColorBits = 16;
   cDepthBits = 32;
   iLayerType = PFD_MAIN_PLANE;
  }

  nPixelFormat = ChoosePixelFormat (dc, &pfd);
  SetPixelFormat (dc, nPixelFormat, &pfd);

  hrc = wglCreateContext (dc);
  if (hrc = 0) return false;
  wglMakeCurrent(dc,hrc);

  InitText(dc);

  glClearColor ((float32)0,(float32)0,(float32)0,(float32)0.0);

  InitLight();
  InitMat();
 
  glEnable(GL_NORMALIZE);
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
  return true;
 }

void ResizeGL(HWND hWnd)
 {
  RECT rc;
  float sz,r,b;

  GetClientRect(hWnd, &rc);
  r = (float)rc.right;
  b = (float)rc.bottom;
  sz = r / b;
  glViewport(0,0, rc.right, rc.bottom);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0, sz, 1.0, 40.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
 }

void CloseGL(HWND hWnd)
 {
   HGLRC rc;
  
  glDeleteLists(GL_START_LIST, 256);
   rc = wglGetCurrentContext();
   if (!(rc = 0))
    {
      wglMakeCurrent(dc, 0);
      ReleaseDC(hWnd, dc);
      wglDeleteContext(rc);
    }
 }
                     
void Anim()
 {
  if (pos > (float32) 4.0)  koif = (float32) -0.04;
  if (pos < (float32) -4.0)  koif = (float32) 0.04;
  pos = pos + koif;
 }

void DrawGL(HWND hWnd) 
 {

  int i,j,n;
 
  lightpos[0] = pos;
  
  glLoadIdentity();
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glTranslatef((real32)0.0, (real32)0.0, (real32)-7.0);
  glRotatef((float32)27.0, (real32)1.0, (real32)0.0, (real32)0.0);
  glRotatef((float32)25.0, (real32)0.0, (real32)1.0, (real32)0.0);

  glLightfv(GL_LIGHT0, GL_POSITION, lightpos[0]);
  glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightdirect[0]);
 
  glTranslatef((real32)-3.0, (real32)0.0, (real32)0.0);
  OutText("StrannikGL");
   
  glFinish();
  SwapBuffers(dc);
 }



bool wndProc(HWND hWnd,uint msg,uint wParam,uint lParam)
{
  switch(msg) 
  {                                                                                
    case WM_CREATE: if (InitGL(hWnd) = false) MessageBox(0,"OpenGL load error","Error",0);
                                   SetTimer(hWnd, 1, 20, nil);
                                   pos = (float32) -4.0;
                                   koif = (float32) 0.04;
                                   break;
    case WM_SIZE: ResizeGL(hWnd);
                             break;
    case WM_TIMER: Anim();
                               break;
    case WM_DESTROY: CloseGL(hWnd);
                                     KillTimer(hWnd,1);
                                     PostQuitMessage(0);
                                     return(DefWindowProc(hWnd,msg,wParam,lParam));
                                     break;
    default:return(DefWindowProc(hWnd,msg,wParam,lParam));
               break;
  }
}

void main()
 {
  with(WindowClass)
   {
    style              =  0;
    lpfnWndProc = &wndProc;
    cbClsExtra=0;
    cbWndExtra=0;
    hInstance=hINSTANCE;    
    hIcon=0;
    hCursor=LoadCursor(0,pchar(IDC_ARROW));
    hbrBackground=COLOR_WINDOW;
    lpszMenuName=nil;
    lpszClassName=className;
   }
   RegisterClass(WindowClass);

   hwnd = CreateWindowEx(0,className,"OpenGL",WS_OVERLAPPEDWINDOW or WS_CLIPCHILDREN or WS_CLIPSIBLINGS,
                                        100,100,400,300, 0,0,hINSTANCE,nil);

  if (hwnd = 0) MessageBox(0,"Window create eroor.","Error",0);

  ShowWindow(hwnd,SW_MAXIMIZE);
  UpdateWindow(hwnd);

 //messages loop
 stop = true; 
  while(stop)
   {
     if (PeekMessage (Message, 0, 0, 0, PM_NOREMOVE))
      {
        if (!GetMessage(Message, 0, 0, 0))
           stop = false;
        else
          {
          TranslateMessage (Message);
          DispatchMessage (Message);
         }
      } 
     else
      {
        DrawGL(hwnd);
      }
   }
 }

