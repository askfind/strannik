// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use Win32)
// Demo 2.15:Use Tab Control

module Demo2_15;
import Win32;

const 
  hINSTANCE=0x400000;
  idTabControl=100;
  idOk=101;
  idEdit1=102;
  idEdit2=103;

//================= main dialog =======================

dialog DLG_MAIN 80,39,160,72,
  WS_POPUP | WS_CAPTION | WS_SYSMENU | DS_MODALFRAME,
  "Demo 2_15:Use Tab Control"
begin
  control "Ok",idOk,"Button",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,55,51,45,14
  control "",idTabControl,"SysTabControl32",WS_CHILD | WS_VISIBLE | TCS_FOCUSNEVER,2,4,150,16
  control "",idEdit1,"Edit",WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | ES_AUTOHSCROLL,12,24,50,15
  control "",idEdit2,"Edit",WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | ES_AUTOHSCROLL,76,24,50,15
end;

//================= dialog function =======================

procedure procDLG_MAIN(wnd:HWND; message,wparam,lparam:integer):boolean;
var item:TC_ITEM; nmInfo:pNMHDR;
begin
  case message of
    WM_INITDIALOG:
//init tabs
      with item do
        RtlZeroMemory(addr(item),sizeof(TC_ITEM));
        mask:=TCIF_TEXT;
        pszText:="Tab 1"; SendDlgItemMessage(wnd,idTabControl,TCM_INSERTITEM,0,cardinal(addr(item)));
        pszText:="Tab 2"; SendDlgItemMessage(wnd,idTabControl,TCM_INSERTITEM,1,cardinal(addr(item)));
        SendDlgItemMessage(wnd,idTabControl,TCM_SETCURSEL,0,0);
      end;
//int dialog items
      ShowWindow(GetDlgItem(wnd,idEdit1),SW_SHOW);
      ShowWindow(GetDlgItem(wnd,idEdit2),SW_HIDE);|
    WM_NOTIFY:
//change tab
      nmInfo:=address(lparam);
      with nmInfo^ do
      case code of
        TCN_SELCHANGE:
          case SendDlgItemMessage(wnd,idTabControl,TCM_GETCURSEL,0,0) of
            0://tab 1
              ShowWindow(GetDlgItem(wnd,idEdit1),SW_SHOW);
              ShowWindow(GetDlgItem(wnd,idEdit2),SW_HIDE);|
            1://tab 2
              ShowWindow(GetDlgItem(wnd,idEdit1),SW_HIDE);
              ShowWindow(GetDlgItem(wnd,idEdit2),SW_SHOW);|
          end;|
      end end;|
    WM_COMMAND:case loword(wparam) of
      IDOK,idOk:EndDialog(wnd,1);|
      IDCANCEL:EndDialog(wnd,0);|
    end;|
  else return false
  end;
  return true
end procDLG_MAIN;

//================= call dialog ====================

begin
  InitCommonControls();
  DialogBoxParam(hINSTANCE,"DLG_MAIN",0,addr(procDLG_MAIN),0);
  ExitProcess(0);
end Demo2_15.

