// STRANNIK Modula-C-Pascal for Win32
// Demo program (Use Win32)
// Demo 2.15:use Tab Control

include Win32

define hINSTANCE 0x400000
define idTabControl 100
define idOk 101
define idEdit1 102
define idEdit2 103

//================= main dialog =======================

dialog DLG_MAIN 80,39,160,72,
  WS_POPUP | WS_CAPTION | WS_SYSMENU | DS_MODALFRAME,
  "Demo 2_15:Use Tab Control"
begin
  control "Ok",idOk,"Button",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,55,51,45,14
  control "",idTabControl,"SysTabControl32",WS_CHILD | WS_VISIBLE | TCS_FOCUSNEVER,2,4,150,16
  control "",idEdit1,"Edit",WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | ES_AUTOHSCROLL,12,24,50,15
  control "",idEdit2,"Edit",WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER | ES_AUTOHSCROLL,76,24,50,15
end;

//================= dialog function =======================

bool procDLG_MAIN(HWND wnd, int message,int wparam,int lparam)
{
TC_ITEM item; pNMHDR nmInfo;

  switch(message) {
    case WM_INITDIALOG:
//init tabs
      with(item) {
        RtlZeroMemory(&item,sizeof(TC_ITEM));
        mask=TCIF_TEXT;
        pszText="Tab 1"; SendDlgItemMessage(wnd,idTabControl,TCM_INSERTITEM,0,cardinal(&item));
        pszText="Tab 2"; SendDlgItemMessage(wnd,idTabControl,TCM_INSERTITEM,1,cardinal(&item));
        SendDlgItemMessage(wnd,idTabControl,TCM_SETCURSEL,0,0);
      }
//init dialog items
      ShowWindow(GetDlgItem(wnd,idEdit1),SW_SHOW);
      ShowWindow(GetDlgItem(wnd,idEdit2),SW_HIDE);
    break;
    case WM_NOTIFY:
//change tab
      nmInfo=(pvoid)lparam;
      switch(nmInfo->code) {
        case TCN_SELCHANGE:
          switch(SendDlgItemMessage(wnd,idTabControl,TCM_GETCURSEL,0,0)) {
            case 0://tab 1
              ShowWindow(GetDlgItem(wnd,idEdit1),SW_SHOW);
              ShowWindow(GetDlgItem(wnd,idEdit2),SW_HIDE);
            break;
            case 1://tab 2
              ShowWindow(GetDlgItem(wnd,idEdit1),SW_HIDE);
              ShowWindow(GetDlgItem(wnd,idEdit2),SW_SHOW);
            break;
          } break;
      }
    break;
    case WM_COMMAND:switch(loword(wparam)) {
      case IDOK:case idOk:EndDialog(wnd,1); break;
      case IDCANCEL:EndDialog(wnd,0); break;
    }
  break;
  default:return false; break;
  }
  return true;
}

//================= call dialog ====================

void main()
{
  InitCommonControls();
  DialogBoxParam(hINSTANCE,"DLG_MAIN",0,&procDLG_MAIN,0);
  ExitProcess(0);
}

